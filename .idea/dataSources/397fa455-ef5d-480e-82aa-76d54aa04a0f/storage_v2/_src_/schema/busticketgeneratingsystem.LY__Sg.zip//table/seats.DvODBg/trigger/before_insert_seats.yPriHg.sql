create definer = root@localhost trigger before_insert_seats
    before insert
    on seats
    for each row
BEGIN
    DECLARE next_id INT;
    SELECT COALESCE(MAX(CAST(SUBSTRING(seat_id, 2) AS UNSIGNED)), 0) + 1 INTO next_id 
    FROM Seats;
    SET NEW.seat_id = CONCAT('S', LPAD(next_id, 4, '0'));
END;

