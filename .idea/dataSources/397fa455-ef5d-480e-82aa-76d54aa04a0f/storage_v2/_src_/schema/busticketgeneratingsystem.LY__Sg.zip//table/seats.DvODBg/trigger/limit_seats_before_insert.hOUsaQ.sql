create definer = root@localhost trigger limit_seats_before_insert
    before insert
    on seats
    for each row
BEGIN
    DECLARE row_count INT;
    
    -- Count the current number of rows in the table
    SELECT COUNT(*) INTO row_count FROM seats;
    
    -- Check if the row count exceeds 50
    IF row_count >= 50 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cannot add more rows. Maximum seat limit (50) reached.';
    END IF;
END;

