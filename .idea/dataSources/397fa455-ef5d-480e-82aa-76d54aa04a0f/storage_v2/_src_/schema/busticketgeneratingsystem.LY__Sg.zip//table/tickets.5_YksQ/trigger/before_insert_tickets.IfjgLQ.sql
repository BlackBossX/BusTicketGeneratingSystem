create definer = root@localhost trigger before_insert_tickets
    before insert
    on tickets
    for each row
BEGIN
    DECLARE next_id INT;
    SELECT COALESCE(MAX(CAST(SUBSTRING(ticket_id, 2) AS UNSIGNED)), 0) + 1 INTO next_id 
    FROM Tickets;
    SET NEW.ticket_id = CONCAT('T', LPAD(next_id, 4, '0'));
END;

