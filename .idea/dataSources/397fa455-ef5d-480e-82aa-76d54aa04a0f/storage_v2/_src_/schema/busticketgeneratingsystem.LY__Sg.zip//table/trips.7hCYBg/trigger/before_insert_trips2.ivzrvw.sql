create definer = root@localhost trigger before_insert_trips2
    before insert
    on trips
    for each row
BEGIN
    DECLARE next_id INT;
    SELECT COALESCE(MAX(CAST(SUBSTRING(trip_id, 2) AS UNSIGNED)), 0) + 1 INTO next_id FROM Trips;
    SET NEW.trip_id = CONCAT('R', LPAD(next_id, 4, '0'));
END;

