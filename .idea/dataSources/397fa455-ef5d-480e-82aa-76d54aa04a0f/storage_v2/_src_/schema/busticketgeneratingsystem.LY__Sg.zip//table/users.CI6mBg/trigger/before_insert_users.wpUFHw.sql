create definer = root@localhost trigger before_insert_users
    before insert
    on users
    for each row
BEGIN
    DECLARE next_id INT;
    SELECT COALESCE(MAX(CAST(SUBSTRING(user_id, 2) AS UNSIGNED)), 0) + 1 INTO next_id FROM Users;
    SET NEW.user_id = CONCAT('U', LPAD(next_id, 4, '0'));
END;

